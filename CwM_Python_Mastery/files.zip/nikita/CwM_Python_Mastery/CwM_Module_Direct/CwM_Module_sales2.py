def calc_volume():
    pass


print("Skript running")


if __name__ == "__main__":
    print("Module started")
    calc_volume()