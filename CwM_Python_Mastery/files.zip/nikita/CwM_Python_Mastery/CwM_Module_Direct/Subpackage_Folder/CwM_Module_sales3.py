def calc_win():
    pass